# Mi Negocio Pro
Proyecto Android independiente para gestión de negocio. Incluye estructura para POS, inventario, clientes, proveedores, compras, gastos, caja, créditos, reportes y configuración.

## Compilar en GitHub
Sube todo el contenido al repositorio. GitHub Actions ejecutará `gradle assembleDebug` y publicará `app-debug.apk` como Artifact.

## Compilar localmente
Abre en Android Studio y ejecuta `assembleDebug`.
