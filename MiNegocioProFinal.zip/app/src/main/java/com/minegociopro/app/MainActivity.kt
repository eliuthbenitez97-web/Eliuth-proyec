package com.minegociopro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import androidx.room.*
import kotlinx.coroutines.launch

@Entity data class Product(@PrimaryKey(autoGenerate=true) val id:Int=0,val name:String,val sku:String="",val cost:Double=0.0,val price:Double=0.0,val stock:Int=0,val minStock:Int=0)
@Dao interface ProductDao { @Query("SELECT * FROM Product ORDER BY name") fun all():kotlinx.coroutines.flow.Flow<List<Product>>; @Insert suspend fun insert(p:Product); @Update suspend fun update(p:Product); @Delete suspend fun delete(p:Product) }
@Database(entities=[Product::class],version=1) abstract class AppDb:RoomDatabase(){abstract fun products():ProductDao; companion object{ @Volatile private var i:AppDb?=null; fun get(c:android.content.Context)=i?: synchronized(this){i?:Room.databaseBuilder(c.applicationContext,AppDb::class.java,"minegociopro.db").build().also{ i=it }} }}

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App(AppDb.get(this))}}}

@Composable fun App(db:AppDb){
 val nav=rememberNavController(); val tabs=listOf("Inicio","Ventas","Inventario","Clientes","Proveedores","Compras","Gastos","Caja","Créditos","Reportes","Configuración")
 Scaffold(bottomBar={NavigationBar{tabs.take(4).forEach{t->NavigationBarItem(selected=false,onClick={nav.navigate(t)},icon={Icon(if(t=="Inicio")Icons.Default.Home else if(t=="Ventas")Icons.Default.ShoppingCart else if(t=="Inventario")Icons.Default.Inventory else Icons.Default.People,null)},label={Text(t)})}}}){p->NavHost(nav,"Inicio",Modifier.padding(p)){composable("Inicio"){Home()};composable("Ventas"){Sales()};composable("Inventario"){Inventory(db)};composable("Clientes"){Module("Clientes")};composable("Proveedores"){Module("Proveedores")};composable("Compras"){Module("Compras")};composable("Gastos"){Module("Gastos")};composable("Caja"){Module("Caja")};composable("Créditos"){Module("Créditos")};composable("Reportes"){Module("Reportes")};composable("Configuración"){Module("Configuración")}}}
}
@Composable fun Home(){Column(Modifier.fillMaxSize().padding(20.dp)){Text("Mi Negocio Pro",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(18.dp));Text("Resumen del negocio");Spacer(Modifier.height(12.dp));Card{Column(Modifier.padding(16.dp)){Text("Ventas de hoy");Text("$0.00",style=MaterialTheme.typography.headlineSmall)}};Spacer(Modifier.height(10.dp));Card{Column(Modifier.padding(16.dp)){Text("Caja");Text("$0.00",style=MaterialTheme.typography.headlineSmall)}}}}
@Composable fun Sales(){Column(Modifier.fillMaxSize().padding(20.dp)){Text("Punto de venta",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp));Text("Carrito vacío");Spacer(Modifier.height(12.dp));Button({}){Text("Nueva venta")}}}
@Composable fun Module(title:String){Column(Modifier.fillMaxSize().padding(20.dp)){Text(title,style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp));Text("Módulo incluido en la estructura de Mi Negocio Pro.")}}
@Composable fun Inventory(db:AppDb){val ps by db.products().all().collectAsState(initial=emptyList());val scope=rememberCoroutineScope();var add by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize().padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Inventario",style=MaterialTheme.typography.headlineMedium);Button({add=true}){Text("+ Producto")}};Spacer(Modifier.height(12.dp));LazyColumn{items(ps){p->Card(Modifier.fillMaxWidth().padding(4.dp)){Column(Modifier.padding(14.dp)){Text(p.name);Text("Código: ${p.sku}");Text("Stock: ${p.stock}   Precio: $${"%.2f".format(p.price)}");if(p.stock<=p.minStock)Text("Stock bajo")}}}}};if(add)ProductDialog({add=false}){scope.launch{db.products().insert(it)};add=false}}
@Composable fun ProductDialog(close:()->Unit,save:(Product)->Unit){var n by remember{mutableStateOf("")};var s by remember{mutableStateOf("")};var c by remember{mutableStateOf("")};var p by remember{mutableStateOf("")};var st by remember{mutableStateOf("")};var min by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,title={Text("Nuevo producto")},text={Column{OutlinedTextField(n,{n=it},label={Text("Nombre")});OutlinedTextField(s,{s=it},label={Text("Código")});OutlinedTextField(c,{c=it},label={Text("Costo")});OutlinedTextField(p,{p=it},label={Text("Precio")});OutlinedTextField(st,{st=it},label={Text("Existencias")});OutlinedTextField(min,{min=it},label={Text("Mínimo")})}},confirmButton={Button({if(n.isNotBlank())save(Product(name=n,sku=s,cost=c.toDoubleOrNull()?:0.0,price=p.toDoubleOrNull()?:0.0,stock=st.toIntOrNull()?:0,minStock=min.toIntOrNull()?:0))}){Text("Guardar")}},dismissButton={TextButton(close){Text("Cancelar")}})}
